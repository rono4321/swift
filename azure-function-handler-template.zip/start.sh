#!/bin/bash
echo "Starting Spring Boot app..."
java -jar spring-hello-world-1.0.0.jar